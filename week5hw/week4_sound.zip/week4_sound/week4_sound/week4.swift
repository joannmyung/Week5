//
//  week4_soundApp.swift
//  week4_sound
//
//  Created by Joann Myung on 2/21/23.
//

import SwiftUI

@main
struct week4_soundApp: App {
    var body: some Scene {
        WindowGroup {
            Page1()
        }
    }
}
