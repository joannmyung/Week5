//
//  Page1.swift
//  week4_sound
//
//  Created by Joann Myung on 2/21/23.
//

import SwiftUI

struct Page1: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Page1_Previews: PreviewProvider {
    static var previews: some View {
        Page1()
    }
}
